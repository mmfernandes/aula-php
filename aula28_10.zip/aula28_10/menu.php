<ul class="nav">
	<li class="nav-item">
		<a href="index.php" class="nav-link">Home</a>
	</li>
	<li class="nav-item">
		<a href="cadastrar.php" class="nav-link">Cadastrar</a>
	</li>
	<li class="nav-item">
		<a href="gerenciar.php" class="nav-link">Gerenciar</a>
	</li>
</ul>